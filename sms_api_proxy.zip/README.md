# SMS API Proxy (Node.js)

Proxy nhỏ để gọi API sms-activation-service.net từ frontend mà không bị CORS.

## Cách dùng trên Render

1. Tạo repo GitHub mới
2. Tải các file này lên repo
3. Truy cập [https://render.com](https://render.com)
4. "New > Web Service" > chọn repo này
5. Cài đặt:
   - Build Command: `npm install`
   - Start Command: `npm start`
6. Đợi build xong, bạn sẽ có link như:
   `https://tên-của-bạn.onrender.com/get-phone`

## Gọi từ HTML:
```javascript
fetch("https://tên-của-bạn.onrender.com/get-phone")
  .then(res => res.text())
  .then(console.log);
```
