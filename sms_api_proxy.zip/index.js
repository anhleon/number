import express from "express";
import axios from "axios";

const app = express();
const PORT = process.env.PORT || 3000;

app.get("/get-phone", async (req, res) => {
  try {
    const apiUrl = "https://sms-activation-service.net/stubs/handler_api?api_key=c63cb1b732460e4a7687e82bdb5fc961&action=getNumber&service=yw&operator=any&country=16&lang=ru";
    const response = await axios.get(apiUrl);
    res.send(response.data);
  } catch (err) {
    res.status(500).send("Lỗi proxy: " + err.message);
  }
});

app.get("/", (req, res) => {
  res.send("Proxy đang hoạt động!");
});

app.listen(PORT, () => console.log("Server chạy tại cổng", PORT));
